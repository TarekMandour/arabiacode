<?php
if (!defined('ABSPATH')) exit;

class BOTSMSG_AI_Agent {

    public function __construct() {
        add_action('rest_api_init', [$this, 'register_webhook']);
    }

    /**
     * Register the public webhook endpoint.
     * URL: POST /wp-json/botsmsg/v1/webhook
     */
    public function register_webhook() {
        register_rest_route('botsmsg/v1', '/webhook', [
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => [$this, 'handle_webhook'],
            'permission_callback' => '__return_true',
        ]);
    }

    /**
     * Handle incoming webhook from BotsMSG.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response
     */
    public function handle_webhook(WP_REST_Request $request) {

        // ── 1. Validate webhook secret (if configured) ───────────────────────
        $secret = get_option('botsmsg_ai_webhook_secret', '');
        if (!empty($secret)) {
            $incoming = $request->get_header('x-botsmsg-secret');
            if (!hash_equals($secret, (string) $incoming)) {
                return new WP_REST_Response(['error' => 'Unauthorized'], 401);
            }
        }

        // ── 2. Parse payload ─────────────────────────────────────────────────
        $body = $request->get_json_params();
        if (empty($body)) {
            $body = $request->get_body_params(); // fallback: form-encoded
        }

        $phone   = $this->extract_phone($body);
        $message = $this->extract_message($body);

        if (empty($phone) || empty($message)) {
            return new WP_REST_Response(['error' => 'Missing phone or message'], 400);
        }

        $phone   = sanitize_text_field($phone);
        $message = sanitize_textarea_field($message);

        // ── 3. Check if AI agent is enabled ──────────────────────────────────
        if (!get_option('botsmsg_ai_enabled', 0)) {
            return new WP_REST_Response(['status' => 'ai_disabled'], 200);
        }

        // ── 4. Off-hours gate ─────────────────────────────────────────────────
        if (get_option('botsmsg_ai_offhours_only', 0)) {
            $start = sanitize_text_field(get_option('botsmsg_ai_offhours_start', '18:00'));
            $end   = sanitize_text_field(get_option('botsmsg_ai_offhours_end',   '09:00'));

            if (!$this->is_offhours($start, $end)) {
                return new WP_REST_Response(['status' => 'within_business_hours'], 200);
            }
        }

        // ── 5. Call Groq AI ───────────────────────────────────────────────────
        $ai_reply = botsmsg_call_groq($message);

        if (!$ai_reply) {
            BOTSMSG_Logs::insert($phone, $message, 'failed', 'Groq API error');
            return new WP_REST_Response(['error' => 'AI error'], 500);
        }

        // ── 6. Send reply via BotsMSG ─────────────────────────────────────────
        botsmsg_send_message($ai_reply, $phone);

        return new WP_REST_Response(['status' => 'ok'], 200);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /**
     * Extract the sender phone number from various BotsMSG payload formats.
     */
    private function extract_phone(array $body): string {
        // Top-level keys
        foreach (['phone', 'from', 'sender', 'mobile', 'number'] as $key) {
            if (!empty($body[$key])) {
                return (string) $body[$key];
            }
        }
        // Nested under 'data'
        if (isset($body['data']) && is_array($body['data'])) {
            foreach (['phone', 'from', 'sender', 'mobile', 'number'] as $key) {
                if (!empty($body['data'][$key])) {
                    return (string) $body['data'][$key];
                }
            }
        }
        return '';
    }

    /**
     * Extract the message text from various BotsMSG payload formats.
     */
    private function extract_message(array $body): string {
        // Top-level keys
        foreach (['message', 'text', 'body', 'content', 'msg'] as $key) {
            if (!empty($body[$key])) {
                return (string) $body[$key];
            }
        }
        // Nested under 'data'
        if (isset($body['data']) && is_array($body['data'])) {
            foreach (['message', 'text', 'body', 'content', 'msg'] as $key) {
                if (!empty($body['data'][$key])) {
                    return (string) $body['data'][$key];
                }
            }
        }
        return '';
    }

    /**
     * Check whether the current WordPress-timezone time falls within the
     * configured off-hours window. Supports midnight-crossing ranges
     * (e.g. 18:00 – 09:00).
     *
     * @param string $start "HH:MM"
     * @param string $end   "HH:MM"
     */
    private function is_offhours(string $start, string $end): bool {
        $now = (int) str_replace(':', '', current_time('H:i')); // e.g. 2130
        $s   = (int) str_replace(':', '', $start);               // e.g. 1800
        $e   = (int) str_replace(':', '', $end);                 // e.g. 0900

        if ($s < $e) {
            // Same-day range: e.g. 09:00 – 18:00
            return ($now >= $s && $now < $e);
        }

        // Midnight-crossing range: e.g. 18:00 – 09:00
        return ($now >= $s || $now < $e);
    }
}
